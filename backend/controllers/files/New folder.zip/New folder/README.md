# DecentraHealth
Our decentralised health-record keeping application.
PORT=8000
MONGOOSE_URL=mongodb://localhost:27017/DecentraHealth